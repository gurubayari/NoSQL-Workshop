"""
Authentication API for Unicorn E-Commerce
Handles user registration, login, token validation, and user management
"""
import json
import boto3
import logging
from typing import Dict, Any, Optional
from botocore.exceptions import ClientError
import uuid
from datetime import datetime

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS services
cognito_client = boto3.client('cognito-idp')
dynamodb = boto3.resource('dynamodb')

# Environment variables
import os
USER_POOL_ID = os.environ.get('USER_POOL_ID')
CLIENT_ID = os.environ.get('CLIENT_ID')
USERS_TABLE = os.environ.get('USERS_TABLE')

def lambda_handler(event, context):
    """Main Lambda handler for authentication operations"""
    try:
        # Parse the request
        http_method = event.get('httpMethod', '')
        path = event.get('path', '')
        body = json.loads(event.get('body', '{}')) if event.get('body') else {}
        headers = event.get('headers', {})
        
        # Route to appropriate handler
        if http_method == 'POST':
            if path.endswith('/register'):
                return handle_register(body)
            elif path.endswith('/login'):
                return handle_login(body)
            elif path.endswith('/refresh'):
                return handle_refresh_token(body)
            elif path.endswith('/logout'):
                return handle_logout(headers)
        elif http_method == 'GET':
            if path.endswith('/profile'):
                return handle_get_profile(headers)
            elif path.endswith('/verify'):
                return handle_verify_token(headers)
        elif http_method == 'PUT':
            if path.endswith('/profile'):
                return handle_update_profile(headers, body)
        
        return create_response(400, {'error': 'Invalid endpoint or method'})
        
    except Exception as e:
        logger.error(f"Authentication API error: {str(e)}")
        return create_response(500, {'error': 'Internal server error'})

def handle_register(body: Dict[str, Any]) -> Dict[str, Any]:
    """Handle user registration"""
    try:
        # Validate required fields
        required_fields = ['email', 'password', 'firstName', 'lastName']
        for field in required_fields:
            if not body.get(field):
                return create_response(400, {'error': f'Missing required field: {field}'})
        
        email = body['email'].lower().strip()
        password = body['password']
        first_name = body['firstName'].strip()
        last_name = body['lastName'].strip()
        
        # Create user in Cognito
        user_attributes = [
            {'Name': 'email', 'Value': email},
            {'Name': 'given_name', 'Value': first_name},
            {'Name': 'family_name', 'Value': last_name},
            {'Name': 'email_verified', 'Value': 'false'}
        ]
        
        cognito_client.admin_create_user(
            UserPoolId=USER_POOL_ID,
            Username=email,
            UserAttributes=user_attributes,
            TemporaryPassword=password,
            MessageAction='SUPPRESS'
        )
        
        # Set permanent password
        cognito_client.admin_set_user_password(
            UserPoolId=USER_POOL_ID,
            Username=email,
            Password=password,
            Permanent=True
        )
        
        # Create user record in DynamoDB
        user_id = str(uuid.uuid4())
        users_table = dynamodb.Table(USERS_TABLE)
        
        user_record = {
            'userId': user_id,
            'email': email,
            'firstName': first_name,
            'lastName': last_name,
            'cognitoUsername': email,
            'createdAt': datetime.utcnow().isoformat(),
            'updatedAt': datetime.utcnow().isoformat(),
            'isActive': True,
            'emailVerified': False
        }
        
        users_table.put_item(Item=user_record)
        
        return create_response(201, {
            'message': 'User registered successfully',
            'userId': user_id,
            'email': email
        })
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'UsernameExistsException':
            return create_response(409, {'error': 'User already exists'})
        else:
            logger.error(f"Registration error: {e}")
            return create_response(500, {'error': 'Registration failed'})

def handle_login(body: Dict[str, Any]) -> Dict[str, Any]:
    """Handle user login"""
    try:
        email = body.get('email', '').lower().strip()
        password = body.get('password', '')
        
        if not email or not password:
            return create_response(400, {'error': 'Email and password are required'})
        
        # Authenticate with Cognito
        auth_response = cognito_client.admin_initiate_auth(
            UserPoolId=USER_POOL_ID,
            ClientId=CLIENT_ID,
            AuthFlow='ADMIN_NO_SRP_AUTH',
            AuthParameters={
                'USERNAME': email,
                'PASSWORD': password
            }
        )
        
        tokens = auth_response['AuthenticationResult']
        
        return create_response(200, {
            'message': 'Login successful',
            'tokens': {
                'accessToken': tokens['AccessToken'],
                'refreshToken': tokens['RefreshToken'],
                'idToken': tokens['IdToken'],
                'expiresIn': tokens['ExpiresIn']
            }
        })
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code in ['NotAuthorizedException', 'UserNotFoundException']:
            return create_response(401, {'error': 'Invalid email or password'})
        else:
            logger.error(f"Login error: {e}")
            return create_response(500, {'error': 'Login failed'})
def han
dle_refresh_token(body: Dict[str, Any]) -> Dict[str, Any]:
    """Handle token refresh"""
    try:
        refresh_token = body.get('refreshToken')
        
        if not refresh_token:
            return create_response(400, {'error': 'Refresh token is required'})
        
        auth_response = cognito_client.admin_initiate_auth(
            UserPoolId=USER_POOL_ID,
            ClientId=CLIENT_ID,
            AuthFlow='REFRESH_TOKEN_AUTH',
            AuthParameters={
                'REFRESH_TOKEN': refresh_token
            }
        )
        
        tokens = auth_response['AuthenticationResult']
        
        return create_response(200, {
            'message': 'Token refreshed successfully',
            'tokens': {
                'accessToken': tokens['AccessToken'],
                'idToken': tokens['IdToken'],
                'expiresIn': tokens['ExpiresIn']
            }
        })
        
    except ClientError as e:
        return create_response(401, {'error': 'Invalid refresh token'})

def handle_logout(headers: Dict[str, str]) -> Dict[str, Any]:
    """Handle user logout"""
    try:
        access_token = extract_token_from_headers(headers)
        
        if not access_token:
            return create_response(400, {'error': 'Access token is required'})
        
        cognito_client.global_sign_out(AccessToken=access_token)
        
        return create_response(200, {'message': 'Logout successful'})
        
    except ClientError as e:
        return create_response(401, {'error': 'Invalid token'})

def handle_get_profile(headers: Dict[str, str]) -> Dict[str, Any]:
    """Get user profile"""
    try:
        user_info = verify_token(headers)
        if not user_info:
            return create_response(401, {'error': 'Invalid or expired token'})
        
        users_table = dynamodb.Table(USERS_TABLE)
        user_response = users_table.query(
            IndexName='EmailIndex',
            KeyConditionExpression='email = :email',
            ExpressionAttributeValues={':email': user_info['email']}
        )
        
        if not user_response['Items']:
            return create_response(404, {'error': 'User not found'})
        
        user = user_response['Items'][0]
        
        return create_response(200, {
            'user': {
                'userId': user['userId'],
                'email': user['email'],
                'firstName': user['firstName'],
                'lastName': user['lastName'],
                'createdAt': user['createdAt']
            }
        })
        
    except Exception as e:
        logger.error(f"Get profile error: {str(e)}")
        return create_response(500, {'error': 'Failed to get profile'})

def handle_update_profile(headers: Dict[str, str], body: Dict[str, Any]) -> Dict[str, Any]:
    """Update user profile"""
    try:
        user_info = verify_token(headers)
        if not user_info:
            return create_response(401, {'error': 'Invalid or expired token'})
        
        users_table = dynamodb.Table(USERS_TABLE)
        user_response = users_table.query(
            IndexName='EmailIndex',
            KeyConditionExpression='email = :email',
            ExpressionAttributeValues={':email': user_info['email']}
        )
        
        if not user_response['Items']:
            return create_response(404, {'error': 'User not found'})
        
        user = user_response['Items'][0]
        
        # Update allowed fields
        update_expression = 'SET updatedAt = :timestamp'
        expression_values = {':timestamp': datetime.utcnow().isoformat()}
        
        if 'firstName' in body:
            update_expression += ', firstName = :firstName'
            expression_values[':firstName'] = body['firstName'].strip()
        
        if 'lastName' in body:
            update_expression += ', lastName = :lastName'
            expression_values[':lastName'] = body['lastName'].strip()
        
        users_table.update_item(
            Key={'userId': user['userId']},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_values
        )
        
        return create_response(200, {'message': 'Profile updated successfully'})
        
    except Exception as e:
        logger.error(f"Update profile error: {str(e)}")
        return create_response(500, {'error': 'Failed to update profile'})

def handle_verify_token(headers: Dict[str, str]) -> Dict[str, Any]:
    """Verify token validity"""
    try:
        user_info = verify_token(headers)
        
        if user_info:
            return create_response(200, {
                'valid': True,
                'user': {
                    'email': user_info['email'],
                    'sub': user_info['sub']
                }
            })
        else:
            return create_response(401, {'valid': False, 'error': 'Invalid token'})
            
    except Exception as e:
        logger.error(f"Token verification error: {str(e)}")
        return create_response(500, {'error': 'Token verification failed'})

def verify_token(headers: Dict[str, str]) -> Optional[Dict[str, Any]]:
    """Verify JWT token and return user info"""
    try:
        access_token = extract_token_from_headers(headers)
        
        if not access_token:
            return None
        
        response = cognito_client.get_user(AccessToken=access_token)
        
        user_info = {'sub': response['Username']}
        for attr in response['UserAttributes']:
            user_info[attr['Name']] = attr['Value']
        
        return user_info
        
    except ClientError as e:
        logger.error(f"Token verification error: {e}")
        return None

def extract_token_from_headers(headers: Dict[str, str]) -> Optional[str]:
    """Extract JWT token from Authorization header"""
    auth_header = headers.get('Authorization') or headers.get('authorization')
    
    if not auth_header:
        return None
    
    if auth_header.startswith('Bearer '):
        return auth_header[7:]
    
    return auth_header

def create_response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Create standardized API response"""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
        },
        'body': json.dumps(body)
    }